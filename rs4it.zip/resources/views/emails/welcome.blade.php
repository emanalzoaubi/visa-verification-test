<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome to RS4IT</title>
</head>
<body>
    <p>Welcome to RS4IT,</p>
    <p>We are sending this email to you to complete your Saudi VIAS entry and travel requirement. Please click on the link below:</p>
    <a href="{{ $link }}">Complete your required data</a>
    <br>
    <p>Thank you for choosing us.</p>
</body>
</html>
