<html>
    <head>
        <title> <?php echo $__env->yieldContent('title'); ?></title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.1/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    </head>
    <body> 
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->yieldContent('scripts'); ?>
        </div>
    </body>
</html><?php /**PATH D:\rs4it\resources\views/layouts/app.blade.php ENDPATH**/ ?>