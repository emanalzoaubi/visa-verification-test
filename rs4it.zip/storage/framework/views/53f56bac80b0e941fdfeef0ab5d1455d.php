<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['name', 'label', 'required' => null, 'type' => 'text','maxlength' => null, 'minlength' => null, 'options' => [], 'errors'=> null]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['name', 'label', 'required' => null, 'type' => 'text','maxlength' => null, 'minlength' => null, 'options' => [], 'errors'=> null]); ?>
<?php foreach (array_filter((['name', 'label', 'required' => null, 'type' => 'text','maxlength' => null, 'minlength' => null, 'options' => [], 'errors'=> null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div  class="form-group">
    <label for="<?php echo e($name); ?>" class="form-label"><?php echo e($label); ?></label>
    <?php if($type == 'select'): ?>
    <select class="form-select"  name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" <?php if($required): ?> required <?php endif; ?>>
            <option value="">Select <?php echo e($label); ?></option>
            <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($option['id']); ?>"><?php echo e($option['name']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    <?php else: ?>
    <input class="form-control <?php if($errors && $errors->has($name)): ?> is-invalid <?php endif; ?>" type="<?php echo e($type); ?>" name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" <?php if($required): ?> required <?php endif; ?> <?php if($maxlength): ?> maxlength="<?php echo e($maxlength); ?>" <?php endif; ?> <?php if($minlength): ?> minlength="<?php echo e($minlength); ?>" <?php endif; ?>/>
        <?php if($errors && $errors->has($name)): ?>
            <div class="invalid-feedback"><?php echo e($errors->first($name)); ?></div>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php /**PATH D:\rs4it\resources\views/components/input-field.blade.php ENDPATH**/ ?>